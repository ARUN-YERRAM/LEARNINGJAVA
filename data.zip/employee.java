public class employee {
    public String name;
    public int age;
    public String dept;
    public int salary;
    public employee(String name, int age,String depString, int salary) {
        this.name = name;
        this.age = age;
        this.dept = depString;
        this.salary = salary;
    }
}
